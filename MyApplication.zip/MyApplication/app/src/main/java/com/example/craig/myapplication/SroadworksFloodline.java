// Name: Craig Keith
// Username: ckeith202
// Student ID: S1425149

package com.example.craig.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedList;

public class SroadworksFloodline extends AppCompatActivity implements View.OnClickListener{

    private String url2 = "https://trafficscotland.org/rss/feeds/roadworks.aspx";
    private String url4 = "http://floodline.sepa.org.uk/feed/";
    private TextView urlInput;
    private Button Button;
    private Button Button1;
    private String result = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.sroadworks_floodline);
        urlInput = (TextView) findViewById(R.id.urlInput);
        Button = (Button) findViewById(R.id.startButton);
        Button.setOnClickListener(this);
        Button1 = (Button) findViewById(R.id.secondButton);
        Button1.setOnClickListener(this);


    } // End of onCreate

    // Pull Parser which looks for specified tag names and stores the tag names within the RSSFeed class.

    private LinkedList<RSSFeed> parseData(String dataToParse) {
        LinkedList<RSSFeed> alist = new LinkedList<RSSFeed>();
        RSSFeed dataFeed = new RSSFeed();

        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();

            xpp.setInput(new StringReader(dataToParse));
            int eventType = xpp.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT) {

                if (eventType == XmlPullParser.START_TAG) {
                    System.out.println("Start tag " + xpp.getName());

                    // Check the tags
                    if (xpp.getName().equalsIgnoreCase("channel")) {
                        alist = new LinkedList<RSSFeed>();
                    } else if (xpp.getName().equalsIgnoreCase("item")) {
                        Log.e("MyTag", "Item Start Tag Found");
                        dataFeed = new RSSFeed();
                    } else if (xpp.getName().equalsIgnoreCase("title")) {
                        String temp = xpp.nextText();
                           Log.e("MyTag", "Title is " + temp);
                        dataFeed.setTitle(temp);
                    } else if (xpp.getName().equalsIgnoreCase("description")) {
                        String temp = xpp.nextText();
                         Log.e("MyTag", "Description is " + temp);
                        dataFeed.setDescription(temp);
                    } else if (xpp.getName().equalsIgnoreCase("link")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Link is " + temp);
                        dataFeed.setLink(temp);
                    }
                    else if (xpp.getName().equalsIgnoreCase("georss")) {

                        String temp = xpp.nextText();

                        Log.e("MyTag", "Geo Point is " + temp);
                        dataFeed.setGeoPoint(temp);
                    } else if (xpp.getName().equalsIgnoreCase("author")) {
                        String temp = xpp.nextText();
                         Log.e("MyTag", "Author is " + temp);
                        dataFeed.setAuthor(temp);
                    } else if (xpp.getName().equalsIgnoreCase("comment")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Comment is " + temp);
                        dataFeed.setComment(temp);
                    } else if (xpp.getName().equalsIgnoreCase("pDate")) {
                        String temp = xpp.nextText();
                         Log.e("MyTag", "Pub Date is " + temp);
                        dataFeed.setPubDate(temp);
                    }
                } else if (eventType == XmlPullParser.END_TAG) {
                    if (xpp.getName().equalsIgnoreCase("item")) {
                        Log.e("MyTag", "indicent feed is " + dataFeed.toString());
                        System.out.print("Incident Feed Is: " + dataFeed.toString());
                        alist.add(dataFeed);
                    } else if (xpp.getName().equalsIgnoreCase("channel")) {
                        int size;
                        size = alist.size();
                        Log.e("MyTag", "channel size " + size);

                    }
                }
                //Get next event
                eventType = xpp.next();
            }

            //END OF WHILE LOOP

            System.out.println("End Document");

            return alist;
        } catch (XmlPullParserException ae1) {
            Log.e("MyTag", "Parsing error" + ae1.toString());
        } catch (IOException ae1) {
            Log.e("MyTag", "IO error during parsing");
        }

        Log.e("MyTag", "End document");

        return alist;
    }

    public void onClick(View aview) {
        startProgress(aview);
    }

    public void startProgress(View aview) {
        // Threads called Task and Task 2, 1 for each url to be parsed.
        if (aview.getId() == R.id.startButton) {
            new Thread(new Task(url2)).start();
        } else if (aview.getId() == R.id.secondButton) {
            new Thread(new Task2(url4)).start();
        }
    }


    class Task implements Runnable {
        private String url2;

        public Task(String aurl) {
            url2 = aurl;
        }


        @Override
        public void run() {

            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.e("MyTag", "in run");

            try {
                Log.e("MyTag", "in try");
                aurl = new URL(url2);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));

                if(!result.equals(""))
                {
                    result = "";
                }
                while ((inputLine = in.readLine()) != null) {
                    result = result + inputLine;


                }
                in.close();
            } catch (IOException ae) {
                Log.e("MyTag", "ioexception");
            }
            final LinkedList<RSSFeed> alist;
            final RSSFeed incidents = new RSSFeed();

            alist = parseData(result);

            if (alist != null) {
                Log.e("MyTag", "List is not null");
                for (Object o : alist) {
                    Log.e("MyTag", o.toString());
                }
            } else {

                Log.e("MyTag", "List is null");
            }


            SroadworksFloodline.this.runOnUiThread(new Runnable() {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");

                    // if the size of alist is equal to 0 then set the urlInput widget to display a message below.

                    if (alist.size() == 0) {
                        urlInput.setText("There is no data on the feed to display currently.");
                    }else {

                        // Replace brackets produced by toString array with nothing.
                        // Replace commas produced by toString array with nothing yet still keeping date commas.

                        urlInput.setText(alist.toString().replace("[", "").replace("]", "").replace(" ,", "").replace(", ", ""));
                    }

                }
            });
        }
    }


    class Task2 implements Runnable {
        private String url4;

        public Task2(String aurl) {
            url4 = aurl;
        }


        @Override
        public void run() {

            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.e("MyTag", "in run");

            try {
                Log.e("MyTag", "in try");
                aurl = new URL(url4);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));





                if(!result.equals(""))
                {
                    result = "";
                }
                while ((inputLine = in.readLine()) != null) {
                    result = result + inputLine;

                    Log.e("MyTag InputLine", inputLine);

                }
                in.close();
            } catch (IOException ae) {
                Log.e("MyTag", "ioexception");
            }


            final LinkedList<RSSFeed> alist;
            final RSSFeed incidents = new RSSFeed();

            alist = parseData(result);

            if (alist != null) {
                Log.e("MyTag", "List is not null");
                for (Object o : alist) {
                    Log.e("MyTag", o.toString());
                }
            } else {

                Log.e("MyTag", "List is null");

            }


            SroadworksFloodline.this.runOnUiThread(new Runnable() {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");



                    // if the size of alist is equal to 0 then set the urlInput widget to display a message below.


                    if (alist.size() == 0) {
                        urlInput.setText("There is no data on the feed to display currently.");
                    }else {

                        // Replace brackets produced by toString array with nothing.
                        // Replace commas produced by toString array with nothing yet still keeping date commas.

                        urlInput.setText(alist.toString().replace("[", "").replace("]", "").replace(" ,", "").replace(", ", ""));
                    }








                }
            });
        }
    }
}
