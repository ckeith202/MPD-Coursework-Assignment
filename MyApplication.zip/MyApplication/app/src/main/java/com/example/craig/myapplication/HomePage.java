// Name: Craig Keith
// Username: ckeith202
// Student ID: S1425149

package com.example.craig.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Map;

public class HomePage extends AppCompatActivity {
    private Button button;
    private Button button2;
    private Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);
        button = (Button)findViewById(R.id.button);
        button2 = (Button)findViewById(R.id.button2);
        button3 = (Button)findViewById(R.id.button3);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IncidentRoadworks();
            }


        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SroadworksFloodline();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapPage();
            }


        });
    }

    public void IncidentRoadworks() {
        Intent intent = new Intent(this,IncidentRoadworks.class);
        startActivity(intent);
    }


    public void SroadworksFloodline() {
        Intent intent = new Intent(this,SroadworksFloodline.class);
        startActivity(intent);
    }

    public void MapPage() {
        Intent intent = new Intent(this,MapPage.class);
        startActivity(intent);
    }
}

