// Name: Craig Keith
// Username: ckeith202
// Student ID: S1425149

package com.example.craig.myapplication;

import android.provider.Settings;
import android.widget.ArrayAdapter;

public class RSSFeed {
    private String title;
    private String description;
    private String link;
    private String geoPoint;
    private String author;
    private String comment;
    private String pubDate;

    public RSSFeed()


    // Assign each String a value.

    {
        title = "";
        description = "";
        link = "";
        geoPoint = "";
        author = "";
        comment = "";
        pubDate = "";
    }


    // Assign each String to a variable.

    public RSSFeed(String atitle, String adescription, String alink, String ageoPoint, String aauthor, String acomment, String apubDate)
    {
        title = atitle;
        description = adescription;
        link = alink;
        geoPoint = ageoPoint;
        author = aauthor;
        comment = acomment;
        pubDate = apubDate;
    }


    // Getters and Setters

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getGeoPoint() {
        return geoPoint;
    }

    public void setGeoPoint(String geoPoint) {
        this.geoPoint = geoPoint;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getPubDate() {
        return pubDate;
    }

    public void setPubDate(String pubDate) {
        this.pubDate = pubDate;
    }


    @Override


    //


    public String toString()
    {
        String temp;

        //And instance of <br /> is changed to take a new line.

        String lineSep = System.getProperty("line.separator");

        temp = "\n" + title + "\n" + description + "\n" + link + "\n" + geoPoint + "" + author + "" + comment + "" + pubDate + "";
        temp = temp.replaceAll("<br />", lineSep);

        return temp;
    }


} // End of class
